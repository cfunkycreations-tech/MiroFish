@echo off
chcp 65001 >nul
title MiroFish 控制台
cd /d "%~dp0"
echo 正在启动 MiroFish（关闭此窗口即退出程序）...
echo 如果窗口一闪而过，请先在 MiroFish.exe 同目录查看 Setup.bat 是否执行成功。
echo.
"MiroFish.exe" --console --no-setup
pause
