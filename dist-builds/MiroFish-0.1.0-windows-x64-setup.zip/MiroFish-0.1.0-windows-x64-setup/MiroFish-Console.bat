@echo off
chcp 65001 >nul
title MiroFish Console (troubleshooting)
cd /d "%~dp0"
echo ============================================================
echo  MiroFish console mode: the app window opens and this window shows the logs
echo ============================================================
echo.
if not exist "runtime\venv\Scripts\python.exe" (
    if not exist "runtime\python\python.exe" (
        echo [Setup] No runtime installed yet, running Setup.bat first ...
        echo.
        call "%~dp0Setup.bat" --no-pause
        if errorlevel 1 (
            echo.
            echo [X] Setup failed; please screenshot the error above and report it.
            pause
            exit /b 1
        )
    )
)
echo Starting MiroFish (close the app window to exit)...
echo.
"MiroFish.exe" --console
echo.
echo [Exit] The app has finished.
pause
