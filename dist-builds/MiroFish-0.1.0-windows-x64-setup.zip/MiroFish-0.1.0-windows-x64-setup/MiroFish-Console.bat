@echo off
chcp 65001 >nul
title MiroFish 控制台（排错用）
cd /d "%~dp0"
echo ============================================================
echo  MiroFish 控制台模式：程序窗口会打开，同时这个黑窗口显示日志
echo ============================================================
echo.
if not exist "runtime\venv\Scripts\python.exe" (
    if not exist "runtime\python\python.exe" (
        echo [初始化] 还没有安装运行环境，先执行 Setup.bat ...
        echo.
        call "%~dp0Setup.bat" --no-pause
        if errorlevel 1 (
            echo.
            echo [X] 初始化失败，请把上面的报错信息截图反馈。
            pause
            exit /b 1
        )
    )
)
echo 正在启动 MiroFish（关闭程序窗口即退出）...
echo.
"MiroFish.exe" --console
echo.
echo [退出] 程序已结束。
pause
