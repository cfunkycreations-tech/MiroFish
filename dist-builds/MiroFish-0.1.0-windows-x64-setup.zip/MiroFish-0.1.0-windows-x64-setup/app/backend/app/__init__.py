"""
MiroFish Backend - the Flask application factory
"""

import os
import warnings

# Suppress the multiprocessing resource_tracker warning (coming from third-party libraries such as transformers)
# This has to be set before every other import
warnings.filterwarnings("ignore", message=".*resource_tracker.*")

from flask import Flask, request
from flask_cors import CORS

from .config import Config
from .utils.logger import setup_logger, get_logger


def create_app(config_class=Config):
    """The Flask application factory"""
    app = Flask(__name__)
    app.config.from_object(config_class)
    
    # Set up the JSON encoding so non-ASCII text shows as-is (instead of \uXXXX)
    # Flask >= 2.3 uses app.json.ensure_ascii; older versions use the JSON_AS_ASCII setting
    if hasattr(app, 'json') and hasattr(app.json, 'ensure_ascii'):
        app.json.ensure_ascii = False
    
    # Set up the logging
    logger = setup_logger('mirofish')
    
    # Print the startup message only in the reloader child process (debug mode would print it twice)
    is_reloader_process = os.environ.get('WERKZEUG_RUN_MAIN') == 'true'
    debug_mode = app.config.get('DEBUG', False)
    should_log_startup = not debug_mode or is_reloader_process
    
    if should_log_startup:
        logger.info("=" * 50)
        logger.info("MiroFish Backend is starting...")
        logger.info("=" * 50)
    
    # Enable CORS
    CORS(app, resources={r"/api/*": {"origins": "*"}})
    
    # Register the simulation process cleanup (so every simulation process is terminated when the server shuts down)
    from .services.simulation_runner import SimulationRunner
    SimulationRunner.register_cleanup()
    if should_log_startup:
        logger.info("The simulation process cleanup handler is registered")
    
    # Request logging middleware
    @app.before_request
    def log_request():
        logger = get_logger('mirofish.request')
        logger.debug(f"Request: {request.method} {request.path}")
        if request.content_type and 'json' in request.content_type:
            logger.debug(f"Request body: {request.get_json(silent=True)}")
    
    @app.after_request
    def log_response(response):
        logger = get_logger('mirofish.request')
        logger.debug(f"Response: {response.status_code}")
        return response
    
    # Register the blueprints
    from .api import graph_bp, simulation_bp, report_bp, desktop_bp
    app.register_blueprint(graph_bp, url_prefix='/api/graph')
    app.register_blueprint(simulation_bp, url_prefix='/api/simulation')
    app.register_blueprint(report_bp, url_prefix='/api/report')
    app.register_blueprint(desktop_bp, url_prefix='/api/desktop')
    
    # Health check
    @app.route('/health')
    def health():
        return {'status': 'ok', 'service': 'MiroFish Backend'}
    
    if should_log_startup:
        logger.info("MiroFish Backend has started")
    
    return app

