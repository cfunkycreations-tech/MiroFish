MiroFish 0.1.0 - Windows x64 desktop build
=================================================

1. Starting
This is the online installer: the first launch of MiroFish.exe offers to download the runtime
(about 500 MB - 1 GB), after which it works offline. You can also run Setup.bat by hand.

    Double-click MiroFish.exe. Data and configuration live in:
        %APPDATA%\MiroFish\
            .env              the configuration file (LLM / Zep API keys)
            uploads\           uploaded documents, graphs, simulations and reports
            logs\desktop.log  the run log
    Upgrading the app never overwrites your configuration or data.

2. API keys are required on first use
    1. Open %APPDATA%\MiroFish\.env in Notepad
    2. Fill in:
           LLM_API_KEY      the LLM API key (any OpenAI-compatible endpoint)
           LLM_BASE_URL     the endpoint address, e.g. https://dashscope.aliyuncs.com/compatible-mode/v1
           LLM_MODEL_NAME   the model name, e.g. qwen-plus
           ZEP_API_KEY      the Zep Cloud memory graph key (free tier at https://app.getzep.com/)
    3. Save the file and restart MiroFish.exe

3. Not enough disk space?
    The install needs about 3 GB at peak (about 1.1 GB once finished). If space is tight:
      * double-click Setup-Slim.bat (or run Setup.bat --slim): no torch is installed,
        which needs about 1.5 GB at peak and about 0.4 GB once finished;
        on the twitter platform "personalized recommendations" degrade to random/popularity ranking, everything else is unchanged.
      * every cache stays in runtime\.cache inside the install directory, so the C: drive is untouched.

4. When something goes wrong
    * Double-click MiroFish-Console.bat: it keeps a console window open so the error is visible.
    * Logs: %APPDATA%\MiroFish\logs\desktop.log
    * The online download was interrupted: double-click MiroFish.exe or Setup.bat again.
    * A blank window: Edge WebView2 is required (usually included with Win10/11);
      install it from https://developer.microsoft.com/microsoft-edge/webview2/;
      as a stopgap run  MiroFish.exe --browser  to use your default browser.

5. Networking and security
    The backend only listens on a random free 127.0.0.1 port and is never exposed.
    While a simulation runs, it calls the LLM / Zep cloud services you configured in .env.

6. License
    AGPL-3.0, see LICENSE.
