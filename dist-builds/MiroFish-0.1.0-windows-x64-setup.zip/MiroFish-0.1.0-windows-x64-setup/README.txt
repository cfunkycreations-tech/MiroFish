MiroFish 0.1.0 · Windows x64 桌面版
=================================================

一、启动
本安装包为在线安装版：首次双击 MiroFish.exe 会提示自动下载运行环境
（约 500 MB - 1 GB），完成后即可离线使用。也可手动双击 Setup.bat。

    双击 MiroFish.exe 即可。数据与配置保存在：
        %APPDATA%\MiroFish\
            .env              配置文件（LLM / Zep 的 API Key）
            uploads\          上传文档、图谱、模拟与报告
            logs\desktop.log  运行日志
    升级软件不会覆盖你的配置与数据。

二、首次使用必须填写 API Key
    1. 用记事本打开 %APPDATA%\MiroFish\.env
    2. 填写：
           LLM_API_KEY      大模型 API Key（任意 OpenAI 兼容接口）
           LLM_BASE_URL     接口地址，如 https://dashscope.aliyuncs.com/compatible-mode/v1
           LLM_MODEL_NAME   模型名，如 qwen-plus
           ZEP_API_KEY      Zep Cloud 记忆图谱 Key（https://app.getzep.com/ 有免费额度）
    3. 保存后重启 MiroFish.exe

三、出问题时
    * 双击 MiroFish-Console.bat：保留控制台窗口，直接看到报错。
    * 日志：%APPDATA%\MiroFish\logs\desktop.log
    * 在线安装版下载中断：重新双击 MiroFish.exe 或 Setup.bat。
    * 窗口空白：需要 Edge WebView2（Win10/11 一般自带），
      可从 https://developer.microsoft.com/microsoft-edge/webview2/ 安装；
      临时可用  MiroFish.exe --browser  在默认浏览器中使用。

四、网络与安全
    后端仅监听 127.0.0.1 的随机空闲端口，不对外开放。
    模拟运行时会调用你在 .env 中配置的 LLM / Zep 云服务。

五、许可
    AGPL-3.0，详见 LICENSE。
