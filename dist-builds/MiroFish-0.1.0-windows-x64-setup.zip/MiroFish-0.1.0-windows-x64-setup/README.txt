MiroFish 0.1.0 - Windows x64 desktop build
=================================================

1. Starting
This is the online installer: the first launch of MiroFish.exe offers to download the runtime
(about 500 MB - 1 GB), after which it works offline. You can also run Setup.bat by hand.

    Double-click MiroFish.exe. Data and configuration live in:
        %APPDATA%\MiroFish\
            .env              the configuration file (LLM / Zep API keys)
            uploads\           uploaded documents, graphs, simulations and reports
            logs\desktop.log  the run log
    Upgrading the app never overwrites your configuration or data.

2. API keys are required on first use
    MiroFish opens its settings page on the first start; the fields can also be edited
    by hand in %APPDATA%\MiroFish\.env. Everything is OpenAI-compatible:

    Free and open routes (no paid account needed):
      OpenRouter : LLM_BASE_URL=https://openrouter.ai/api/v1
                   LLM_MODEL_NAME=openrouter/free
                   free key at https://openrouter.ai/keys; ":free" models cost nothing
      OmniRoute  : LLM_BASE_URL=http://127.0.0.1:20128/v1, LLM_MODEL_NAME=auto
                   (npm install -g omniroute; its API key is optional by default)
      Ollama     : LLM_BASE_URL=http://127.0.0.1:11434/v1, LLM_MODEL_NAME=llama3.1 (no key needed)
      Groq       : LLM_BASE_URL=https://api.groq.com/openai/v1, llama-3.3-70b-versatile
      Gemini     : LLM_BASE_URL=https://generativelanguage.googleapis.com/v1beta/openai,
                   gemini-2.5-flash
    Paid routes: Alibaba Bailian (dashscope), OpenAI, DeepSeek.

    LLM_API_KEY is required for remote providers; local ones (Ollama, LM Studio,
    OmniRoute) work with the key left empty.
    ZEP_API_KEY is the Zep Cloud memory graph key (free tier at https://app.getzep.com/).

3. Not enough disk space?
    The install needs about 3 GB at peak (about 1.1 GB once finished). If space is tight:
      * double-click Setup-Slim.bat (or run Setup.bat --slim): no torch is installed,
        which needs about 1.5 GB at peak and about 0.4 GB once finished;
        on the twitter platform "personalized recommendations" degrade to random/popularity ranking, everything else is unchanged.
      * every cache stays in runtime\.cache inside the install directory, so the C: drive is untouched.

4. When something goes wrong
    * FIRST: double-click MiroFish-Doctor.bat. It writes doctor-report.txt next to this file
      and opens it. That report contains the Windows version, every Python / Miniconda /
      Anaconda installation that was found, the free space, the antivirus state and the
      complete last Setup.bat log. Send that file and the cause is immediately visible.
    * Double-click MiroFish-Console.bat: it keeps a console window open so the error is visible.
    * Setup.bat started from MiroFish.exe writes %~dp0runtime\setup.log (previous run: setup.log.old).
    * Logs: %APPDATA%\MiroFish\logs\desktop.log
    * The online download was interrupted: double-click MiroFish.exe or Setup.bat again.
    * A blank window: Edge WebView2 is required (usually included with Win10/11);
      install it from https://developer.microsoft.com/microsoft-edge/webview2/;
      as a stopgap run  MiroFish.exe --browser  to use your default browser.

5. Networking and security
    The backend only listens on a random free 127.0.0.1 port and is never exposed.
    While a simulation runs, it calls the LLM / Zep cloud services you configured in .env.

6. License
    AGPL-3.0, see LICENSE.
